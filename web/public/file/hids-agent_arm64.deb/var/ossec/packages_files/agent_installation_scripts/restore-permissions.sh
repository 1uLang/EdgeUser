#!/bin/sh
chown -- 'ossec:ossec' '/var/ossec/queue/rids'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/rids'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/queue/logcollector'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/logcollector'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/queue/alerts'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/queue/alerts'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/queue/sockets'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/queue/sockets'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/queue/fim/db'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/fim/db'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/queue/fim'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/fim'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/queue/diff'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/diff'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/queue/syscollector/norm_config.json'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/queue/syscollector/norm_config.json'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/queue/syscollector/db'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/syscollector/db'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/queue/syscollector'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue/syscollector'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/queue'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/queue'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/tmp'  > /dev/null 2>&1 || :
chmod 1770 '/var/ossec/tmp'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/ruleset/sca/cis_debian9.yml'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/ruleset/sca/cis_debian9.yml'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/ruleset/sca'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/ruleset/sca'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/ruleset'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/ruleset'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/backup'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/backup'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/agent-auth'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/agent-auth'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-agentd'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-agentd'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/manage_agents'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/manage_agents'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-syscheckd'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-syscheckd'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-modulesd'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-modulesd'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-execd'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-execd'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-logcollector'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-logcollector'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin/wazuh-control'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin/wazuh-control'  > /dev/null 2>&1 || :
chown -- 'root:root' '/var/ossec/bin'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/bin'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles/aws/aws-s3'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws/aws-s3'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles/aws'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/aws'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles/__init__.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/__init__.py'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles/docker/DockerListener'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/docker/DockerListener'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles/docker'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/docker'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles/utils.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/utils.py'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles/gcloud/integration.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/integration.py'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles/gcloud/tools.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/tools.py'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles/gcloud/gcloud'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud/gcloud'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles/gcloud'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles/gcloud'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/wodles'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/wodles'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/lib/libwazuhshared.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libwazuhshared.so'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/lib/libsysinfo.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libsysinfo.so'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/lib/libsyscollector.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libsyscollector.so'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/lib/libwazuhext.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libwazuhext.so'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/lib/librsync.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/librsync.so'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/lib/libdbsync.so'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib/libdbsync.so'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/lib'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/lib'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_mysql5-6_community_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_mysql5-6_community_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_win2012r2_memberL2_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_win2012r2_memberL2_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_debian_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_debian_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/win_malware_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/win_malware_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_rhel6_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_rhel6_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_mysql5-6_enterprise_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_mysql5-6_enterprise_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/rootkit_trojans.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/rootkit_trojans.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_sles12_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_sles12_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_win2012r2_domainL1_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_win2012r2_domainL1_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/system_audit_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/system_audit_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_rhel7_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_rhel7_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/rootkit_files.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/rootkit_files.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/win_audit_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/win_audit_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_rhel5_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_rhel5_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_rhel_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_rhel_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/win_applications_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/win_applications_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/system_audit_ssh.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/system_audit_ssh.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_win2012r2_domainL2_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_win2012r2_domainL2_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_apache2224_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_apache2224_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_win2012r2_memberL1_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_win2012r2_memberL1_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared/cis_sles11_linux_rcl.txt'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/shared/cis_sles11_linux_rcl.txt'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/shared'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/etc/shared'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/wpk_root.pem'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/etc/wpk_root.pem'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/localtime'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/etc/localtime'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/local_internal_options.conf'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/etc/local_internal_options.conf'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/client.keys'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/etc/client.keys'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/ossec.conf'  > /dev/null 2>&1 || :
chmod 660 '/var/ossec/etc/ossec.conf'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/etc/internal_options.conf'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/etc/internal_options.conf'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/etc'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/etc'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/var/wodles'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/var/wodles'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/var/selinux/wazuh.pp'  > /dev/null 2>&1 || :
chmod 640 '/var/ossec/var/selinux/wazuh.pp'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/var/selinux'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/var/selinux'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/var/run'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/var/run'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/var/upgrade'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/var/upgrade'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/var/incoming'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/var/incoming'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/var'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/var'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/ssh.exp'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh.exp'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/ssh_generic_diff'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_generic_diff'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/ssh_foundry_diff'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_foundry_diff'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/ssh_nopass.exp'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_nopass.exp'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/register_host.sh'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/register_host.sh'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/sshlogin.exp'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/sshlogin.exp'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/ssh_pixconfig_diff'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_pixconfig_diff'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/ssh_asa-fwsmconfig_diff'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_asa-fwsmconfig_diff'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/ssh_integrity_check_linux'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_integrity_check_linux'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/su.exp'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/su.exp'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/ssh_integrity_check_bsd'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/ssh_integrity_check_bsd'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless/main.exp'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless/main.exp'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/agentless'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/agentless'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/logs/wazuh'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/logs/wazuh'  > /dev/null 2>&1 || :
chown -- 'ossec:ossec' '/var/ossec/logs'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/logs'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/pf'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/pf'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/kaspersky'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/kaspersky'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/host-deny'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/host-deny'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/restart.sh'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/restart.sh'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/wazuh-slack'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/wazuh-slack'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/ipfw'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/ipfw'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/restart-wazuh'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/restart-wazuh'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/ip-customblock'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/ip-customblock'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/kaspersky.py'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/kaspersky.py'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/firewalld-drop'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/firewalld-drop'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/npf'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/npf'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/route-null'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/route-null'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/default-firewall-drop'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/default-firewall-drop'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/firewall-drop'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/firewall-drop'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin/disable-account'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin/disable-account'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response/bin'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response/bin'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/active-response'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/active-response'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/.ssh'  > /dev/null 2>&1 || :
chmod 770 '/var/ossec/.ssh'  > /dev/null 2>&1 || :
chown -- 'root:ossec' '/var/ossec/'  > /dev/null 2>&1 || :
chmod 750 '/var/ossec/'  > /dev/null 2>&1 || :
